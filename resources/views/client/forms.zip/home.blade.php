@extends('layouts.app-client')
@section('title', 'Dashboard')
@section('content')

@endsection